import 'package:flutter/material.dart';
import 'data/activity_data.dart';
import 'repositories/activity_repository.dart';
import 'viewmodels/activity_viewmodel.dart';
import 'views/home_view.dart';

void main() {
  // Inisialisasi layer Data, Repository, dan ViewModel
  final activityData = ActivityData();
  final activityRepository = ActivityRepository(activityData);
  final activityViewModel = ActivityViewModel(activityRepository);

  runApp(MyApp(viewModel: activityViewModel));
}

class MyApp extends StatelessWidget {
  final ActivityViewModel viewModel;

  const MyApp({super.key, required this.viewModel});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Activity Counter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: HomeView(viewModel: viewModel),
    );
  }
}