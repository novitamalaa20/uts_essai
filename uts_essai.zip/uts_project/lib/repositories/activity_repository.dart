import '../data/activity_data.dart';
import '../models/activity_model.dart';

class ActivityRepository {
  final ActivityData _activityData;

  ActivityRepository(this._activityData);

  // Mengambil seluruh data aktivitas
  List<ActivityModel> getAllActivities() {
    return List.unmodifiable(_activityData.activities);
  }

  // Mengambil satu aktivitas berdasarkan ID
  ActivityModel? getActivityById(String id) {
    try {
      return _activityData.activities.firstWhere((item) => item.id == id);
    } catch (_) {
      return null;
    }
  }

  // Menambahkan aktivitas baru
  void addActivity(ActivityModel activity) {
    _activityData.activities.add(activity);
  }

  // Mengubah nama aktivitas
  void updateActivity(String id, String newName) {
    final index = _activityData.activities.indexWhere((item) => item.id == id);
    if (index != -1) {
      _activityData.activities[index].name = newName;
    }
  }

  // Menghapus aktivitas
  void deleteActivity(String id) {
    _activityData.activities.removeWhere((item) => item.id == id);
  }

  // Memperbarui nilai counter
  void updateCounter(String id, int newCount) {
    final index = _activityData.activities.indexWhere((item) => item.id == id);
    if (index != -1) {
      _activityData.activities[index].count = newCount;
    }
  }
}