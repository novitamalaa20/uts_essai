import 'package:flutter/foundation.dart';
import '../models/activity_model.dart';
import '../repositories/activity_repository.dart';

class ActivityViewModel extends ChangeNotifier {
  final ActivityRepository _repository;

  ActivityViewModel(this._repository) {
    loadActivities();
  }

  List<ActivityModel> _activities = [];
  List<ActivityModel> get activities => _activities;

  // Meminta data aktivitas dari Repository
  void loadActivities() {
    _activities = _repository.getAllActivities();
    notifyListeners();
  }

  // Mengambil detail aktivitas terkini berdasarkan ID
  ActivityModel? getActivityById(String id) {
    return _repository.getActivityById(id);
  }

  // Menambahkan aktivitas baru
  void addActivity(String name) {
    final newActivity = ActivityModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name.trim(),
      count: 0,
    );
    _repository.addActivity(newActivity);
    loadActivities();
  }

  // Mengubah nama aktivitas
  void updateActivityName(String id, String newName) {
    _repository.updateActivity(id, newName.trim());
    loadActivities();
  }

  // Menghapus aktivitas
  void deleteActivity(String id) {
    _repository.deleteActivity(id);
    loadActivities();
  }

  // Menambah nilai counter (+1)
  void incrementCounter(String id) {
    final activity = _repository.getActivityById(id);
    if (activity != null) {
      _repository.updateCounter(id, activity.count + 1);
      loadActivities();
    }
  }

  // Mengurangi nilai counter (-1), tidak boleh kurang dari 0
  bool decrementCounter(String id) {
    final activity = _repository.getActivityById(id);
    if (activity != null && activity.count > 0) {
      _repository.updateCounter(id, activity.count - 1);
      loadActivities();
      return true;
    }
    return false;
  }

  // Mengembalikan nilai counter menjadi 0
  void resetCounter(String id) {
    final activity = _repository.getActivityById(id);
    if (activity != null) {
      _repository.updateCounter(id, 0);
      loadActivities();
    }
  }
}