class ActivityModel {
  final String id;
  String name;
  int count;

  ActivityModel({
    required this.id,
    required this.name,
    this.count = 0,
  });
}