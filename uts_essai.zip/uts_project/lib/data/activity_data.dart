import '../models/activity_model.dart';

class ActivityData {
  // Penyimpanan data sementara menggunakan List selama aplikasi berjalan
  final List<ActivityModel> activities = [
    ActivityModel(id: '1', name: 'Membaca Buku (Bab)', count: 2),
    ActivityModel(id: '2', name: 'Olahraga Push-Up (Set)', count: 3),
    ActivityModel(id: '3', name: 'Mengerjakan Tugas Kuliah', count: 1),
  ];
}